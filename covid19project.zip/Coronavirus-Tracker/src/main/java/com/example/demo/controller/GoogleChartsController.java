package com.example.demo.controller;

import java.util.Map;
import java.util.TreeMap;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class GoogleChartsController {
    @GetMapping("/")
    public String getPieChart(Model model) {
        Map<String, Integer> graphData = new TreeMap<>();
        graphData.put("Afghanistan",7896);
        graphData.put("Albania", 3598);
        graphData.put("Algeria",6881);
        graphData.put("Andorra", 165);
        graphData.put("Angola", 1933);
        graphData.put("Antarctica", 0);
        graphData.put("Antigua and Barbuda	", 146);
        graphData.put("Argentina", 130472);
        graphData.put("Armenia", 8727);
        graphData.put("Australia",165);
        graphData.put("Austria",21970);
        graphData.put("Azerbaijan",10138);
        graphData.put("Bahamas",833);
        graphData.put("Bahrain",1553);
        graphData.put("Bangladesh",29445);
        graphData.put("Barbados",579);
        graphData.put("Belarus",7118);
        graphData.put("Belgium",33814);
        graphData.put("Belize",688);
        graphData.put("Benin",163);
        graphData.put("Bhutan",21);
        graphData.put("Bolivia",22365);
        graphData.put("Bosnia and Herzegovina",16280);
        graphData.put("Botswana",2801);
        graphData.put("Brazil",699276);
        graphData.put("Brunei",225);
        graphData.put("Bulgaria",38288);
        graphData.put("Burkina Faso	",396);
        graphData.put("Burma",19490);
        graphData.put("Burundi",38);
        graphData.put("Cabo Verde",413);
        graphData.put("Cambodia",3056);
        graphData.put("Cameroon",1965);
        graphData.put("Canada",5622);
        graphData.put("Central African Republic	",133); 
        graphData.put("China",300000);
        graphData.put("Colombia",142339);
        graphData.put("Croatia",17987);
        graphData.put("Czechia",42491);
        graphData.put("Denmark	",8296);
        graphData.put("Ecuador	",36014);
        graphData.put("Georgia	",16971);
        graphData.put("Germany",168935);
        graphData.put("	",64273);
        graphData.put("168935	",34779);
        graphData.put("Guatemala	",20182);
        graphData.put("Honduras	",11111);
        graphData.put("	Hungary",48762);
        graphData.put("India",530779);
        graphData.put("Indonesia	",160941);
        graphData.put("Iran	",144933);
        graphData.put("Iraq	",25375);
        graphData.put("Ireland	",8708);
        graphData.put("italy	",188322);
        graphData.put("Japan	",72997);
        graphData.put("korea	",34093);
        graphData.put("Malaysia	",36967);
        graphData.put("Mexico	",333188);
        graphData.put("nepal	",12020);
        graphData.put("Netherlands	",22990);
        graphData.put("Zealand	",2548);
        graphData.put("Pakistan	",30644);
        graphData.put("Peru	",219539);
        graphData.put("Philippines	",66188);
        graphData.put("Poland	",119010);
        graphData.put("Portugal	",26266);
        graphData.put("Rusia	",388478);
        graphData.put("Saudi Arabia		",9618);
        graphData.put("Serbia	",17881);
        graphData.put("South Africa	",102595);
        graphData.put("Spain	",119479);
        graphData.put("Sri Langa	",16830);
        graphData.put("Switzerland	",14210);
        graphData.put("Taiwan	",17672);
        graphData.put("Thailand	",33918);
        graphData.put("Turkey	",101492);
        graphData.put("Us	",1123836);
        graphData.put("Ukraine	",119283);
        graphData.put("United Kingdom		",219948);
        graphData.put("Yeman	",2159);
        graphData.put("Zambia	",4057);
        graphData.put("Zimbabwe	",5671);
        
        
        
        
        model.addAttribute("chartData", graphData);
        return "google-charts";
    }
}